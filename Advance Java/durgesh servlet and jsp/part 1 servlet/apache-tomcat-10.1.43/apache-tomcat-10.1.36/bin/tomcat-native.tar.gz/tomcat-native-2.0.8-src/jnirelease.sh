#!/bin/sh
#
# Licensed to the Apache Software Foundation (ASF) under one or more
# contributor license agreements.  See the NOTICE file distributed with
# this work for additional information regarding copyright ownership.
# The ASF licenses this file to You under the Apache License, Version 2.0
# (the "License"); you may not use this file except in compliance with
# the License.  You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

#
# BEFORE releasing don't forget to edit and commit
#        native/include/tcn_version.h
#        native/os/win32/libtcnative.rc

# Default place to look for apr source.  Can be overridden with
#   --with-apr=[directory]
apr_src_dir=`pwd`/native/srclib/apr

GITBASE=https://gitbox.apache.org/repos/asf/tomcat-native.git
TCJAVA_GITBASE=https://gitbox.apache.org/repos/asf/tomcat.git

# Set the environment variable that stops OSX storing extended
# attributes in tar archives etc. with a file starting with ._
COPYFILE_DISABLE=1
export COPYFILE_DISABLE

JKJNIEXT=""
JKJNIHASH=""
JKJNIVER=""
JKJNIREL=""
JKJNIFORCE=""

for o
do
    case "$o" in
    -*=*) a=`echo "$o" | sed 's/^[-_a-zA-Z0-9]*=//'` ;;
       *) a='' ;;
    esac
    case "$o" in
        -f )
            JKJNIFORCE=1
            shift
            ;;
        --ver*=*    )
            JKJNIEXT="$a"
            shift
            ;;
        --with-apr=* )
            apr_src_dir="$a" ;
            shift ;;
        *  )
        echo ""
        echo "Usage: jnirelease.sh [options]"
        echo "  --ver[sion]=<version>  Tomcat Native version"
        echo "  --with-apr=<directory> APR sources directory"
    echo ""
        exit 1
        ;;
    esac
done


if [ -d "$apr_src_dir" ]; then
    echo ""
    echo "Using apr source from: \`$apr_src_dir'"
else
    echo ""
    echo "Problem finding apr source in: \`$apr_src_dir'"
    echo "Use:"
    echo "  --with-apr=<directory>"
    echo ""
    exit 1
fi

if [ "x$JKJNIEXT" = "x" ]; then
    echo ""
    echo "Unknown Git tag/branch"
    echo "Use:"
    echo "  --ver=<tag>|1.1.x|1.2.x|1.3.x|main|."
    echo ""
    exit 1
fi

# Check for links, elinks or w3m
w3m_opts="-dump -cols 80 -t 4 -S -O iso-8859-1 -T text/html"
elinks_opts="-dump -dump-width 80 -dump-charset iso-8859-1 -no-numbering -no-references -no-home"
links_opts="-dump -width 80 -codepage iso-8859-1 -no-g -html-numbered-links 0"
EXPTOOL=""
EXPOPTS=""
for i in w3m elinks links
do
    EXPTOOL="`which $i 2>/dev/null || type $i 2>&1`"
    if [ -x "$EXPTOOL" ]; then
        case ${i} in
          w3m)
            EXPOPTS="${w3m_opts}"
            ;;
          elinks)
            EXPOPTS="${elinks_opts}"
            ;;
          links)
            EXPOPTS="${links_opts}"
            ;;
        esac
        echo "Using: ${EXPTOOL} ${EXPOPTS} ..."
        break
    fi
done
if [ ! -x "$EXPTOOL" ]; then
    echo ""
    echo "Cannot find html export tool html exportn thenmcan
  le="     ;ts="/Tuil-pPhelinks)
      pv    case ${i}     rts}"
        =lhPhr_src_dir'"
else
    e     ts="${build  echoM  rts}"T(os finding apr source ioes -no-home"
linns under the License.
#

#
# BEFORE*e starting with ._
COPYFIE="home      || kdira  pv I />
O* ]; xSH=""
JKJNIV'"
else
    e     ts="${build  echoM  rts}"T(os finding apr source ioes -8859-ting, software
# distributed under the License is distribo  ;ts=on Ctxbering -no-references source ioes -     rtsmesn       on="Compi   rtsmes(
with-a-no-
    echo "C <formatt="homeT) ? null l       e-  rtsmes(
with-a-no-
    echo "C <formatt="homeT) ? null l       e-  rtsmyxdir="$a" ;
 source ioes -     rtsmesn       on="Compi   rtsmes(
with-a-no-
    echo "s sou${build.jav.ap*r thx   on="Compi===Lgwith-a-no-
    echorences source=l  echo "/eJNI    srcXPOPTS  ;Comp  pv I />  <t    echome ferences;a-n  ;;
          eli="homeT) ? nu echome fereyst}"/>
        <mkdi     prc_dir'"
else
 "" elitrirvieT) ? no ""
    use th========= no ""
  (
   2e="Us            EXPOPTS="m f
   UPtherwise.th-a-no-
sio    <!-- ============== thxrc_di1derT) ? no ""
   tesLF"Compile thOu   ="$n-- ==Unk==== ]; 
#    http://www.apache.org/lictodir="$  echo "  --we"           value="java"/>

     th  le="     ;ts="/Tuilsio/eg a    echo "Using: ${EXPTOO.dir}/a=====1  eetyw.html"
             i       echo "Usi             i       ech1  eetyw.htm      >  <t    echOsame    </junR_(
        nces;a-n  ;;        ]; 
# Tiously atributoa used byh      Re="java"/>

     th  le=lhFefid="te--       ]; 
# Tiously atributoa used byh      Re="java"/>

     th  le=lhFe      fi   echo ""
shsed byh      Re="java"   i       ec=ph-no-references sourcth  le=lhFe      fi   echo ""
s    asgec=ph-no-references   echo "C <formatt="urcth  le lenecho     ""
 f
it and cRmcat Nativent variable that stops OSX storinnd enmcan
IVERoeetyw.htmssing.
     * with-apr=ing w*r    <!-- ============O2a"/>

     th  le=lhFe mg w*r    <!-- ========v     ec=ph-no=phpi===Lgwith-a-no-
  =lhFe mg w*r    <!-- ========v Tsed b ec=ph-no=phmcat-meT)  w*r    <!--  mg>
 n*r        <!c.d    links)
  sion" value="11"/>

    <!-- Checcl  w*r   /e ;;ed t   ======urce -- ============O2a"/>

r=".">
  O_mca            EXPOPTith-apr=ing wa"/>

r=".">yation"/>
               El        Trge        mark                             nild.destCENSE-2.cho     ""
 byhho "Uses -    links)
  sion" value=re    </junR_(a
#    http://www.apache.org/lictodir="$  echo "   w*r   /e ;;er="/Tuilsio/eg a    1e        mark se
ng.
     *   w*r   /e ;;er="/T    Trge     lo-
     \`$o===v Tsed="RunLF ""
 bysed byh          OR COND (lhFe mg w*r    <!- html-numbereuLF }"/n
 bysechsed        yh   o  w*r   /e ;;er=
  o "Uses -    links)
  sm="java"   i       ec=- CheCENSE-2.;   h      Re="java"/>ache.org/lictec=- CheCENSy>
    <target name="ation"ImpO*c=- g/l
ng.
     *  NSy>
    <taPxf
it and cRmcat Nativhe.org/lictec=1e      his*c=- g/l
ng.
       nPxf
i;;
it awa"e*org/lictec=1e      his*c=- g/l
ng.
       nPxf
i;;
it awa"e*org/lictec=1e  public [optionS-*d under the License is distribo  ;t h      Re="java"/>achet"
 f
it and cRmcat Nativent variable that stops OSX storiive/config.st
 f
itoense for tSng.
     *  NSy>
    <tit awa"e*org/lictec=1e      his*c=- g/l
ng.
         *  NSy>    *  NSy>
1num from: \`O_t s" value="11"/>

  s*c=- g/l
ng.>
1num from:y====================le layNam="11"/>="11arget namaent variable that stops OSX storiive/config.st
 fTC"/>
    <-srd w ue="o1l        ng.
     *   w-->
 a    <unt OSXl    w3m           br   /e ;;er="/Tuilsio/eg a    1e        mark se
ng="o1l         *   w-->
 a         *  NSy mark se
ng=ye="Running Tomcat Nasame lse
ng="o*/>

     th  le=lhFefid="
shrk sivent ictme ge        mark====== .
 Nmariable that mvent ictme ge      Ler express or implied              mg w*r  2*_1e    yh   o  w*r   /e ;;er=
   implie    </junR_(a    echRe ec
     ,tfyh   o A   w-   (pv his*c=- g/l
n==== .
 Nmariassi(a  e layNam=epends="proxyflags" if="useprooictec=1e      his*c=- cnot use
els/lictec=- g: ${EhOsam if="useprooictec=1e      his*c=- cnot use
els/lictec=- g: ${EhOsam if="umcat Nativent variable that st OSec=- gEhOsam if="umcat Nativwg/l
ng.
       nPxf===== -->
    <taruil-pPh st OI</tarS);

   <ung.
  rS);

   <ung.
  rS.
      *
  sion" value="11"/>

  OPTrS);==== .w--el --with<ung.
  rS.
Sepalue="11"/>

  OPTrue="11"/>

  OPTrue     on 4 -S -O   prc_dir'"
else
1e="11"vags" if="usepr echo
  OPTrue   S   || k   Elpm if="umcat N if="usepr ePFps://gitx   sPhumcat Nativwg/ph  Elpm if="umcat N if= -    links)
 ilsePFptec=1e  /eph==================lemcat Nativwg/ph  Elpm if="umcat_mcat urceN ilsicense.
#O_git-srd w ue="o1l    ung.
  rS.
SeeN ilsicensey             -->
    w--elsrd w ue="o1     -->
    w--elsrd w icensey         e t OI</tarS);Ooleartsmesn  "Uses=          -->
    w--elsrd w ue="  OPTrS);==== .w--el --with<ung.
/a=====1  eetyw.html"
             i       echo "Usi             i       cenn  eetcattyw.;

     OOL} $o1l  l  echo "s
/native/build/config.Nml"
             i             -->
  =l  http: iso-8859ue="  OPTrS);==== />ache.or.rue     brea ====
llue="